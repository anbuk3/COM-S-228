package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Anbu Krishnan
 *
 */
class TownTest {

	private String string = "O R O R \n" + "E E C O \n" + "E S O S \n" + "E O R R \n";

	private Town t = new Town(4, 4);

	@Test
	void testLength() {
		assertEquals(t.getLength(), 4);
	}

	@Test
	void testWidth() {
		assertEquals(t.getWidth(), 4);
	}

	@Test
	void testToString() {
		t.randomInit(10);
		assertEquals(t.toString(), string);
	}

	@Test
	void testRandomInit() {
		t.randomInit(10);
		assertEquals(t.toString(), string);
	}

	@Test
	public void testTownFile() throws FileNotFoundException {
		Town town = new Town("ISP4x4.txt");
		assertEquals(town.toString(), string);
	}

}
