package edu.iastate.cs228.hw1;

/**
 * 
 * @author Anbu Krishnan
 * A subclass of TownCEll for the specific cell type Empty
 */
public class Empty extends TownCell {

	private int row; // row
	private int col; // column

	/**
	 * A Empty object is created that is shown by "E" in the output/ towns grid
	 * 
	 * @param tNew
	 * @param row
	 * @param col
	 */
	public Empty(Town p, int r, int c) {
		super(p, r, c);
		row = r;
		col = c;
	}

	/**
	 * Gets the identity of the cell.
	 *
	 * @return State
	 */
	@Override
	public State who() {
		return State.EMPTY;
	}

	/**
	 * Determines the cell type in the next cycle.
	 *
	 * @param tNew : town of the next cycle
	 * @return TownCell
	 */
	@Override
	public TownCell next(Town tNew) {
		int[] nCensus = new int[5];
		census(nCensus);
		if (nCensus[EMPTY] + nCensus[OUTAGE] <= 1) {
			return new Reseller(tNew, row, col);
		}
		return new Casual(tNew, row, col);
	}
}
