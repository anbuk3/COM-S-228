package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Anbu Krishnan
 *
 */
class OutageTest {

	Town t = new Town(4, 4);
	Outage o = new Outage(t, 1, 0);

	@Test
	public void testWho() {
		assertEquals(o.who(), State.OUTAGE);
	}

	@Test
	public void testNext() {
		assertEquals(o.who(), State.EMPTY);
	}

}
