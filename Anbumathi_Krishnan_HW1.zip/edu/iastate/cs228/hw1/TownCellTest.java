package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Anbu Krishnan
 *
 */
class TownCellTest {

	private Town t = new Town(4, 4);
	private int[] census = { 2, 1, 2, 2, 0 };
	private Reseller res = new Reseller(t, 0, 1);

	@Test
	void testCensus() {
		int[] census = new int[5];
		t.randomInit(10);
		res.census(census);
		assertEquals(Arrays.toString(census), Arrays.toString(this.census));
	}

}
