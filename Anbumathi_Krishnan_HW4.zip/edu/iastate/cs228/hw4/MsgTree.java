package edu.iastate.cs228.hw4;

/**
 * 
 * @author Anbu Krishnan
 *
 */
public class MsgTree {

	public char payloadChar;
	public MsgTree left;
	public MsgTree right;

	/*
	 * Tracks all of the characters in the final message
	 */
	public static int total = 0;

	/*
	 * can use a static char idx to the tree string for recursive solution, but it
	 * is not strictly necessary.
	 */
	private static int staticCharIdx = 0;

	/**
	 * Constructor building the tree from a string
	 * 
	 * @param encodingString
	 */
	public MsgTree(String encodingString) {
		payloadChar = encodingString.charAt(staticCharIdx);
		staticCharIdx++;

		if (payloadChar != '^') {
			return;
		}

		left = new MsgTree(encodingString);
		right = new MsgTree(encodingString);
	}

	/**
	 * Constructor for a single node with null children
	 * 
	 * @param payloadChar
	 */
	public MsgTree(char payloadChar) {
		left = null;
		right = null;
		this.payloadChar = payloadChar;
	}

	/**
	 * Method to print characters and their binary codes. Performs recursive
	 * preorder traversal of the MsgTree and prints all the characters and their bit
	 * codes
	 * 
	 * @param root
	 * @param code
	 */
	public static void printCodes(MsgTree root, String code) {
		if (root.payloadChar == '\n') {
			System.out.println("  \\n" + "     " + code);
		} else if (root.payloadChar != '^') {
			System.out.println("  " + root.payloadChar + "         " + code);

		}
		if (root.left != null) {
			printCodes(root.left, code + "0");
		}
		if (root.right != null) {
			printCodes(root.right, code + "1");
		}
	}

	/**
	 * Decodes the message, and helps print the decoded message to the console.
	 * 
	 * @param codes
	 * @param msg
	 */
	public static void decode(MsgTree codes, String msg) {
		int idx = 0;
		MsgTree current = codes;
		String decMessage = "";

		while (idx < msg.length()) {
			if (current.payloadChar == '^') {
				if (msg.charAt(idx) == '0') {
					current = current.left;
				} else {
					current = current.right;
				}
				if (current.payloadChar != '^') {
					decMessage = decMessage + current.payloadChar;
					current = codes;
					total++;

				}
				idx++;
			} else {
				decMessage = decMessage + current.payloadChar;
				current = codes;
				total++;
			}
		}
		System.out.println(decMessage);
	}
}
