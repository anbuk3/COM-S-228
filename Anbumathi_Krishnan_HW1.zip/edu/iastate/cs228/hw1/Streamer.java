package edu.iastate.cs228.hw1;

/**
 * 
 * @author Anbu Krishnan
 * A Subclass of TownCell for the specific type cell Streamer
 */
public class Streamer extends TownCell {
	private int row; // row
	private int col; // Colum

	/**
	 * A Streamer object is created that is shown by "S" in the output/ towns grid
	 * 
	 * @param tNew
	 * @param row
	 * @param col
	 */
	public Streamer(Town tNew, int row, int col) {
		super(tNew, row, col);
		this.row = row;
		this.col = col;

	}

	/**
	 * Gets the identity of the cell.
	 *
	 * @return State
	 */
	@Override
	public State who() {
		return State.STREAMER;
	}

	/**
	 * Determines the cell type in the next cycle.
	 *
	 * @param tNew : town of the next cycle
	 * @return TownCell
	 */
	@Override
	public TownCell next(Town tNew) {
		int[] nCensus = new int[5];
		census(nCensus);
		if (nCensus[EMPTY] + nCensus[OUTAGE] <= 1) {
			return new Reseller(tNew, row, col);
		} else if (nCensus[RESELLER] > 0) {
			return new Outage(tNew, row, col);
		} else if (nCensus[OUTAGE] > 0) {
			return new Empty(tNew, row, col);
		}

		return new Streamer(tNew, row, col);

	}
}
