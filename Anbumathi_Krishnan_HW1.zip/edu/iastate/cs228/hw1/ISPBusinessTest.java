package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Anbu Krishnan
 *
 */
class ISPBusinessTest {

	Town town = new Town(4, 4);

	@Test
	void testGetProfit() {
		Town t = new Town(4, 4);
		t.randomInit(10);
		assertEquals(ISPBusiness.getProfit(t), 1);
	}

	@Test
	void testUpdatePlain() {
		Town t = new Town(4, 4);
		town.randomInit(10);

		for (int i = 0; i < t.getLength(); i++) {
			for (int j = 0; j < t.getWidth(); j++) {
				t.grid[i][j] = town.grid[i][j].next(t);
			}
		}

		assertEquals(ISPBusiness.updatePlain(town).toString(), t.toString());
	}

}
