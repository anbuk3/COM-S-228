package edu.iastate.cs228.hw4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * 
 * @author Anbu Krishnan
 *
 */
public class Main {

	// C:\\Users\\anbuk\\eclipse-workspace\\Anbumathi_Krishnan_HW4\\src\\cadbard.arch
	// C:\\Users\\anbuk\\eclipse-workspace\\Anbumathi_Krishnan_HW4\\src\\constitution.arch
	// C:\\Users\\anbuk\\eclipse-workspace\\Anbumathi_Krishnan_HW4\\src\\monalisa.arch
	// C:\\Users\\anbuk\\eclipse-workspace\\Anbumathi_Krishnan_HW4\\src\\twocities.arch

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter filename to decode: ");
		String fileName = input.nextLine();
		input.close();

		File file = new File(fileName);
		Scanner fileScnr = new Scanner(file);
		String encodingString = fileScnr.nextLine();
		String message = fileScnr.nextLine();

		if (fileScnr.hasNext()) {
			encodingString = encodingString + "\n" + message;
			message = fileScnr.nextLine();
		}

		fileScnr.close();

		String c = "";
		MsgTree r = new MsgTree(encodingString);

		System.out.println("character   code\n-------------------------");
		MsgTree.printCodes(r, c);

		System.out.println("\nMessage:");
		MsgTree.decode(r, message);

		double compressedBits = (double) message.length() / MsgTree.total;
		double spaceSavings = (1.0 - (compressedBits / 16.0)) * 100.0;

		System.out.println("\n\nSTATISTICS: ");
		System.out.printf("Avg bits/char:        " + "%.2f", compressedBits);
		System.out.println("\nTotal characters:     " + MsgTree.total);
		System.out.printf("Space savings:        " + "%.2f", spaceSavings);
		System.out.print("%");

	}

}
