package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.lang.IllegalArgumentException;
import java.util.InputMismatchException;

/**
 *  
 * @author Anbu Krishnan
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.
 *
 */

public class MergeSorter extends AbstractSorter {
	// Other private instance variables if needed

	/**
	 * Constructor takes an array of points. It invokes the superclass constructor,
	 * and also set the instance variables algorithm in the superclass.
	 * 
	 * @param pts input array of integers
	 */
	public MergeSorter(Point[] pts) {
		// TODO
		super(pts);
		super.algorithm = "mergesort";
	}

	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter.
	 * 
	 */
	@Override
	public void sort() {
		// TODO
		mergeSortRec(points);
	}

	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of
	 * points. One way is to make copies of the two halves of pts[], recursively
	 * call mergeSort on them, and merge the two sorted subarrays into pts[].
	 * 
	 * @param pts point array
	 */
	private void mergeSortRec(Point[] pts) {
		int x = pts.length;
		int y = x / 2;
		int z = 0;

		if (x <= 1) {
			return;
		}

		Point[] leftHalf = new Point[y];
		Point[] rightHalf = new Point[x - y];

		for (int i = 0; i < y; i++) {
			leftHalf[i] = pts[i];
		}

		for (int i = y; i < x; i++) {
			rightHalf[z] = pts[i];
			z++;
		}
		mergeSortRec(leftHalf);
		mergeSortRec(rightHalf);

		Point[] p = new Point[pts.length];
		p = merges(leftHalf, rightHalf);

		for (int i = 0; i < p.length; i++) {
			pts[i] = p[i];
		}
	}

	// Other private methods if needed ...
	/**
	 * Private method merges two array points
	 * 
	 * @param x
	 * @param y
	 * @return c
	 */
	private Point[] merges(Point[] x, Point[] y) {
		int p = x.length;
		int q = y.length;

		Point[] c = new Point[p + q];

		int i = 0;
		int j = 0;
		int t = 0;

		while ((i < p) && (j < q)) {
			if (pointComparator.compare(x[i], y[j]) <= 0) {
				c[t++] = x[i];
				i++;
			} else {
				c[t++] = y[j];
				j++;
			}
		}

		if (i >= p) {
			for (int z = j; z < q; z++) {
				c[t++] = y[z];
			}

		} else {
			for (int z = i; z < p; z++) {
				c[t++] = x[z];
			}
		}

		return (c);
	}

}