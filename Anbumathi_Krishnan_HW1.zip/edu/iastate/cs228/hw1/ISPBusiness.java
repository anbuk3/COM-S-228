package edu.iastate.cs228.hw1;

import java.io.FileNotFoundException;
import java.util.Scanner;
import static edu.iastate.cs228.hw1.TownCell.*;

/**
 * 
 * @author Anbu Krishnan
 * The ISPBusiness class performs simulation over a grid plain
 * With cells occupied by different TownCell types
 */
public class ISPBusiness {
	private static int[] nCensus = new int[5];

	private static int totalProfit;

	private static int profit;

	/**
	 * Returns a new Town object with updated grid value for next billing cycle.
	 * 
	 * @param tOld old/current Town object.
	 * @return: New town object.
	 */
	public static Town updatePlain(Town tOld) {
		Town tNew = new Town(tOld.getLength(), tOld.getWidth());

		for (int i = 0; i < tOld.getLength(); i++) {
			for (int j = 0; j < tOld.getWidth(); j++) {
				tNew.grid[i][j] = tOld.grid[i][j].next(tNew);
			}
		}
		return tNew;
	}

	/**
	 * Returns the profit for the current state in the town grid.
	 * 
	 * @param town
	 * @return nCensus
	 */
	public static int getProfit(Town town) {
		nCensus[2] = 0;
		int row = town.getLength();
		int col = town.getWidth();
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				if (town.grid[i][j].who() == State.CASUAL) {
					nCensus[2] += 1;
				}
			}
		}
		return nCensus[2];
	}

	/**
	 * Main method. Interact with the user and ask if user wants to specify elements
	 * of grid via an input file (option: 1) or wants to generate it randomly
	 * (option: 2).
	 * 
	 * Depending on the user choice, create the Town object using respective
	 * constructor and if user choice is to populate it randomly, then populate the
	 * grid here.
	 * 
	 * Finally: For 12 billing cycle calculate the profit and update town object
	 * (for each cycle). Print the final profit in terms of %. You should print the
	 * profit percentage with two digits after the decimal point: Example if profit
	 * is 35.5600004, your output should be:
	 *
	 * 35.56%
	 * 
	 * Note that this method does not throw any exception, so you need to handle all
	 * the exceptions in it.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		// TODO: Write your code here.
		Scanner s = new Scanner(System.in);
		String str = "";

		Town t = null;

		int x;
		int y;
		int seed;
		boolean f = false;
		boolean g = false;

		while (!g) {
			System.out.println("How to populate grid (type 1 or 2): 1: from a file. 2: randomly with seed");
			str = s.next();
			switch (str) {
			case "1":
				while (!f) {
					try {
						System.out.println("Please enter file path:");
						str = s.next();
						t = new Town(str);
						f = true;
					} catch (Exception e) {
						System.out.println("File not found");
					}
				}

				g = true;
				break;
			case "2":
				System.out.println("Provide rows, columns and seed integer separated by spaces:");
				x = s.nextInt();
				y = s.nextInt();
				seed = s.nextInt();
				t = new Town(x, y);
				t.randomInit(seed);
				g = true;
				break;

			}
		}

		for (int i = 0; i < 10; i++) { // Iterations 2 through 11
			Town t2 = updatePlain(t);
			profit = getProfit(t2);
			totalProfit += profit;
			t = t2;
		}

		// Profit Utilization
		Town t2 = updatePlain(t);
		profit = getProfit(t2);
		totalProfit += profit;
		totalProfit /= 12;
		System.out.println();
		System.out.println("Profit: " + (100.00 * totalProfit) / (t.getLength() * t.getWidth()) + "%");
		t = t2;

		s.close();
	}
}
