package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Anbu Krishnan
 *
 */
class StreamerTest {

	Town t = new Town(4, 4);
	Streamer stream = new Streamer(t, 2, 3);

	@Test
	void testWho() {
		assertEquals(stream.who(), State.STREAMER);
	}

	@Test
	void testNext() {
		t.randomInit(10);
		assertEquals(stream.next(t).who(), State.OUTAGE);
	}
}
