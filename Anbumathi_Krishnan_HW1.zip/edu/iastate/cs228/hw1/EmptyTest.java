package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Anbu Krishnan
 *
 */
class EmptyTest {

	Town t = new Town(4, 4);
	Empty e = new Empty(t, 1, 0);

	@Test
	void testWho() {
		assertEquals(e.who(), State.EMPTY);
	}

	@Test
	void testNext() {
		t.randomInit(10);
		assertEquals(e.next(t).who(), State.CASUAL);
	}
}
