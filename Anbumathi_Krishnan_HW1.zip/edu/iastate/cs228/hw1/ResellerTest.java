package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Anbu Krishnan
 *
 */
class ResellerTest {

	Town t = new Town(4, 4);
	Reseller res = new Reseller(t, 0, 1);

	@Test
	void testWho() {

		assertEquals(res.who(), State.RESELLER);
	}

	@Test
	void testNext() {
		t.randomInit(10);
		assertEquals(res.next(t).who(), State.EMPTY);
	}

}
