package edu.iastate.cs228.hw1;

/**
 * 
 * @author Anbu Krishnan
 * A subclass of TownCell for the specific type cell Reseller
 */
public class Reseller extends TownCell {

	private int row; // row
	private int col; // column

	/**
	 * A Reseller object is created that is shown by "R" in the output/ towns grid
	 * 
	 * @param tNew
	 * @param row
	 * @param col
	 */
	public Reseller(Town p, int r, int c) {
		super(p, r, c);
		row = r;
		col = c;

	}

	/**
	 * Gets the identity of the cell.
	 *
	 * @return State
	 */
	@Override
	public State who() {
		return State.RESELLER;
	}

	/**
	 * Determines the cell type in the next cycle.
	 *
	 * @param tNew : town of the next cycle
	 * @return TownCell
	 */
	@Override
	public TownCell next(Town tNew) {
		int[] nCensus = new int[5];
		census(nCensus);
		if (nCensus[CASUAL] <= 3 || nCensus[EMPTY] <= 3) {
			return new Empty(tNew, row, col);
		} else if (nCensus[CASUAL] >= 5) {
			return new Streamer(tNew, row, col);
		}

		return new Casual(tNew, row, col);

	}
}
